import math
import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
from torch import nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import torchvision.transforms as transforms
from PIL import Image
import cv2
import os
import argparse
from tqdm import tqdm
from torch import amp


value_map = {
    0: 0,
    100: 1,
    200: 2,
    300: 3,
    500: 4,
    550: 5,
    700: 6,
    800: 7,
    7100: 8,
    10000: 9
}

n_classes = len(value_map)

class_names = [
    'Background', 'Trees', 'Lush Bushes', 'Dry Grass', 'Dry Bushes',
    'Ground Clutter', 'Logs', 'Rocks', 'Landscape', 'Sky'
]

color_palette = np.array([
    [70, 70, 70],
    [34, 139, 34],
    [0, 255, 127],
    [255, 215, 0],
    [210, 105, 30],
    [128, 128, 0],
    [139, 69, 19],
    [169, 169, 169],
    [222, 184, 135],
    [135, 206, 235],
], dtype=np.uint8)


def denormalize_image(img_tensor):
    img = img_tensor.cpu().numpy()
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    img = np.moveaxis(img, 0, -1)
    img = img * std + mean
    img = np.clip(img, 0, 1)
    return img


def convert_mask(mask):
    arr = np.array(mask)
    new_arr = np.zeros_like(arr, dtype=np.uint8)
    for raw_value, new_value in value_map.items():
        new_arr[arr == raw_value] = new_value
    return Image.fromarray(new_arr)


def mask_to_color(mask):
    return color_palette[mask]


def create_overlay(image, mask, alpha=0.5):
    if image.max() <= 1.0:
        image = (image * 255).astype(np.uint8)
    else:
        image = image.astype(np.uint8)
    
    mask_color = mask_to_color(mask)
    overlay = cv2.addWeighted(image, 1 - alpha, mask_color, alpha, 0)
    return overlay


class InferenceDataset(Dataset):
    def __init__(self, data_dir, transform=None, mask_transform=None, has_gt=True):
        self.image_dir = os.path.join(data_dir, 'Color_Images')
        self.masks_dir = os.path.join(data_dir, 'Segmentation') if has_gt else None
        self.transform = transform
        self.mask_transform = mask_transform
        self.has_gt = has_gt
        
        self.data_ids = sorted([f for f in os.listdir(self.image_dir) 
                                if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
        
        print(f"Found {len(self.data_ids)} images in {self.image_dir}")
        if has_gt and self.masks_dir:
            print(f"Ground truth masks: {self.masks_dir}")
        else:
            print("Running inference without ground truth masks")

    def __len__(self):
        return len(self.data_ids)

    def __getitem__(self, idx):
        data_id = self.data_ids[idx]
        img_path = os.path.join(self.image_dir, data_id)

        image = Image.open(img_path).convert("RGB")
        original_size = image.size

        if self.has_gt and self.masks_dir:
            mask_path = os.path.join(self.masks_dir, data_id)
            if os.path.exists(mask_path):
                mask = Image.open(mask_path)
                mask = convert_mask(mask)
            else:
                mask = Image.fromarray(np.zeros((original_size[1], original_size[0]), dtype=np.uint8))
        else:
            mask = Image.fromarray(np.zeros((original_size[1], original_size[0]), dtype=np.uint8))

        if self.transform:
            image = self.transform(image)
            mask = self.mask_transform(mask) * 255

        return image, mask, data_id, original_size


class _ASPPConv(nn.Sequential):
    def __init__(self, in_ch, out_ch, dilation):
        super().__init__(
            nn.Conv2d(in_ch, out_ch, 3, padding=dilation, dilation=dilation, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.GELU(),
        )


class _ASPPPooling(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.pool = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_ch, out_ch, 1, bias=True),
            nn.GELU(),
        )

    def forward(self, x):
        size = x.shape[2:]
        out = self.pool(x)
        return F.interpolate(out, size=size, mode="bilinear", align_corners=False)


class ASPP(nn.Module):
    def __init__(self, in_ch, out_ch=256, rates=(6, 12, 18)):
        super().__init__()
        modules = [
            nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1, bias=False),
                nn.BatchNorm2d(out_ch),
                nn.GELU(),
            )
        ]
        for rate in rates:
            modules.append(_ASPPConv(in_ch, out_ch, rate))
        modules.append(_ASPPPooling(in_ch, out_ch))

        self.branches = nn.ModuleList(modules)
        self.project = nn.Sequential(
            nn.Conv2d(out_ch * len(self.branches), out_ch, 1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.GELU(),
            nn.Dropout(0.1),
        )

    def forward(self, x):
        out = torch.cat([branch(x) for branch in self.branches], dim=1)
        return self.project(out)


class PositionalEncoding2D(nn.Module):
    def __init__(self, n_freqs=8):
        super().__init__()
        self.n_freqs = n_freqs
        self.out_channels = n_freqs * 2 * 2

    def forward(self, x):
        B, C, H, W = x.shape
        device = x.device
        y_coords = torch.linspace(0, 1, H, device=device).view(1, 1, H, 1).expand(B, 1, H, W)
        x_coords = torch.linspace(0, 1, W, device=device).view(1, 1, 1, W).expand(B, 1, H, W)
        pe_list = []
        for freq in range(self.n_freqs):
            factor = 2 ** freq
            pe_list.append(torch.sin(2 * math.pi * factor * y_coords))
            pe_list.append(torch.cos(2 * math.pi * factor * y_coords))
            pe_list.append(torch.sin(2 * math.pi * factor * x_coords))
            pe_list.append(torch.cos(2 * math.pi * factor * x_coords))
        pe = torch.cat(pe_list, dim=1)
        return pe


class ConvNeXtBlock(nn.Module):
    def __init__(self, in_channels, out_channels=None, expansion=4):
        super().__init__()
        out_channels = out_channels or in_channels
        hidden_dim = in_channels * expansion

        self.dwconv = nn.Conv2d(in_channels, in_channels, kernel_size=7, padding=3, groups=in_channels)
        self.norm = nn.LayerNorm(in_channels)
        self.pwconv1 = nn.Linear(in_channels, hidden_dim)
        self.act = nn.GELU()
        self.pwconv2 = nn.Linear(hidden_dim, out_channels)
        
        self.shortcut = nn.Identity() if in_channels == out_channels else nn.Conv2d(in_channels, out_channels, 1)

    def forward(self, x):
        input = x
        x = self.dwconv(x)
        x = x.permute(0, 2, 3, 1)
        x = self.norm(x)
        x = self.pwconv1(x)
        x = self.act(x)
        x = self.pwconv2(x)
        x = x.permute(0, 3, 1, 2)
        x = x + self.shortcut(input)
        return x


class SegmentationHeadConvNeXt(nn.Module):
    def __init__(self, in_channels, out_channels, tokenW, tokenH):
        super().__init__()
        self.tokenW = tokenW
        self.tokenH = tokenH
        
        self.pos_enc = PositionalEncoding2D(n_freqs=8)
        pe_channels = self.pos_enc.out_channels
        
        self.aspp = ASPP(in_channels, out_ch=256, rates=(6, 12, 18))
        
        total_in = 256 + pe_channels
        
        self.conv1 = nn.Sequential(
            nn.Conv2d(total_in, 512, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(512),
            nn.GELU(),
        )
        
        self.convnext1 = ConvNeXtBlock(512, 512, expansion=4)
        self.convnext2 = ConvNeXtBlock(512, 512, expansion=4)
        
        self.conv2 = nn.Sequential(
            nn.Conv2d(512, 256, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(256),
            nn.GELU(),
        )
        
        self.classifier = nn.Conv2d(256, out_channels, kernel_size=1)

    def forward(self, x):
        B, N, C = x.shape
        x = x.transpose(1, 2).reshape(B, C, self.tokenH, self.tokenW)
        
        pos_enc = self.pos_enc(x)
        aspp_out = self.aspp(x)
        x = torch.cat([aspp_out, pos_enc], dim=1)
        
        x = self.conv1(x)
        x = self.convnext1(x)
        x = self.convnext2(x)
        x = self.conv2(x)
        x = self.classifier(x)
        
        return x


def compute_iou_per_class(outputs, labels, num_classes):
    preds = torch.argmax(outputs, dim=1)
    iou_list = []
    
    for cls in range(num_classes):
        pred_mask = (preds == cls)
        true_mask = (labels == cls)
        
        intersection = (pred_mask & true_mask).sum().float()
        union = (pred_mask | true_mask).sum().float()
        
        if union == 0:
            iou_list.append(float('nan'))
        else:
            iou_list.append((intersection / union).item())
    
    iou_list = np.array(iou_list)
    mean_iou = np.nanmean(iou_list)
    
    return mean_iou, iou_list


def compute_pixel_accuracy(outputs, labels):
    preds = torch.argmax(outputs, dim=1)
    correct = (preds == labels).sum().item()
    total = labels.numel()
    return correct / total


def save_prediction_visualization(image, pred_mask, save_path, image_id, gt_mask=None, original_size=None):
    img_denorm = denormalize_image(image)
    
    pred_mask_np = pred_mask.cpu().numpy().astype(np.uint8)
    pred_color = mask_to_color(pred_mask_np)
    
    if gt_mask is not None:
        gt_mask_np = gt_mask.cpu().numpy().astype(np.uint8)
        gt_color = mask_to_color(gt_mask_np)
        
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        axes[0, 0].imshow(img_denorm)
        axes[0, 0].set_title(f'Original Image\n{image_id}', fontsize=12)
        axes[0, 0].axis('off')
        
        axes[0, 1].imshow(gt_color)
        axes[0, 1].set_title('Ground Truth', fontsize=12)
        axes[0, 1].axis('off')
        
        axes[1, 0].imshow(pred_color)
        axes[1, 0].set_title('Prediction', fontsize=12)
        axes[1, 0].axis('off')
        
        overlay = create_overlay(img_denorm, pred_mask_np, alpha=0.5)
        axes[1, 1].imshow(overlay)
        axes[1, 1].set_title('Overlay', fontsize=12)
        axes[1, 1].axis('off')
    else:
        fig, axes = plt.subplots(1, 3, figsize=(18, 6))
        
        axes[0].imshow(img_denorm)
        axes[0].set_title(f'Original Image\n{image_id}', fontsize=12)
        axes[0].axis('off')
        
        axes[1].imshow(pred_color)
        axes[1].set_title('Prediction', fontsize=12)
        axes[1].axis('off')
        
        overlay = create_overlay(img_denorm, pred_mask_np, alpha=0.5)
        axes[2].imshow(overlay)
        axes[2].set_title('Overlay', fontsize=12)
        axes[2].axis('off')
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()


def create_legend(save_path):
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.axis('off')
    
    legend_elements = []
    for i, (color, name) in enumerate(zip(color_palette, class_names)):
        color_normalized = color / 255.0
        patch = plt.Rectangle((0, 0), 1, 1, fc=color_normalized)
        legend_elements.append(patch)
    
    legend = ax.legend(legend_elements, class_names, loc='center', 
                      frameon=True, fontsize=12, ncol=2)
    legend.get_frame().set_facecolor('white')
    legend.get_frame().set_alpha(1.0)
    
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()


def save_metrics_summary(results, output_dir, has_gt=True):
    if has_gt:
        metrics_path = os.path.join(output_dir, 'evaluation_metrics.txt')
        with open(metrics_path, 'w') as f:
            f.write("Evaluation Metrics\n")
            f.write("=" * 50 + "\n\n")
            f.write(f"Mean IoU:          {results['mean_iou']:.4f}\n")
            f.write(f"Pixel Accuracy:    {results['mean_pixel_acc']:.4f}\n\n")
            f.write("Per-Class IoU:\n")
            f.write("-" * 50 + "\n")
            for name, iou in zip(class_names, results['class_iou']):
                if not np.isnan(iou):
                    f.write(f"  {name:<20}: {iou:.4f}\n")
                else:
                    f.write(f"  {name:<20}: N/A\n")
        
        fig, ax = plt.subplots(figsize=(10, 6))
        valid_classes = [i for i, iou in enumerate(results['class_iou']) if not np.isnan(iou)]
        valid_iou = [results['class_iou'][i] for i in valid_classes]
        valid_names = [class_names[i] for i in valid_classes]
        
        bars = ax.bar(valid_names, valid_iou, color='steelblue', alpha=0.7)
        ax.set_ylabel('IoU Score', fontsize=12)
        ax.set_title('Per-Class IoU Performance', fontsize=14, fontweight='bold')
        ax.set_ylim(0, 1.0)
        ax.grid(axis='y', alpha=0.3)
        ax.axhline(y=results['mean_iou'], color='red', linestyle='--', 
                   linewidth=2, label=f"Mean IoU: {results['mean_iou']:.4f}")
        ax.legend()
        
        for i, bar in enumerate(bars):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{height:.3f}', ha='center', va='bottom', fontsize=9)
        
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        chart_path = os.path.join(output_dir, 'per_class_iou.png')
        plt.savefig(chart_path, dpi=150, bbox_inches='tight')
        plt.close()


def main():
    parser = argparse.ArgumentParser(description='Segmentation Inference')
    parser.add_argument('--data_dir', type=str, required=True,
                       help='Path to data directory')
    parser.add_argument('--model_path', type=str, required=True,
                       help='Path to trained model checkpoint')
    parser.add_argument('--output_dir', type=str, default='./inference_output',
                       help='Output directory for results')
    parser.add_argument('--batch_size', type=int, default=4,
                       help='Batch size for inference')
    parser.add_argument('--num_vis', type=int, default=10,
                       help='Number of detailed visualizations to save')
    parser.add_argument('--no_gt', action='store_true',
                       help='Run inference without ground truth masks')
    
    args = parser.parse_args()
    
    has_gt = not args.no_gt

    os.makedirs(args.output_dir, exist_ok=True)
    masks_dir = os.path.join(args.output_dir, 'masks')
    masks_color_dir = os.path.join(args.output_dir, 'masks_color')
    overlays_dir = os.path.join(args.output_dir, 'overlays')
    visualizations_dir = os.path.join(args.output_dir, 'visualizations')
    
    os.makedirs(masks_dir, exist_ok=True)
    os.makedirs(masks_color_dir, exist_ok=True)
    os.makedirs(overlays_dir, exist_ok=True)
    os.makedirs(visualizations_dir, exist_ok=True)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    if device.type == 'cuda':
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB\n")

    w, h = 672, 378
    print(f"Processing size: {h}x{w}")

    transform = transforms.Compose([
        transforms.Resize((h, w)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    mask_transform = transforms.Compose([
        transforms.Resize((h, w)),
        transforms.ToTensor(),
    ])

    print("Loading dataset...")
    dataset = InferenceDataset(
        data_dir=args.data_dir, 
        transform=transform, 
        mask_transform=mask_transform,
        has_gt=has_gt
    )
    
    dataloader = DataLoader(
        dataset, 
        batch_size=args.batch_size, 
        shuffle=False,
        num_workers=0
    )
    
    print(f"Loaded {len(dataset)} images\n")

    print("Loading DINOv2 backbone...")
    BACKBONE_SIZE = "base"
    backbone_name = "dinov2_vitb14_reg"

    backbone = torch.hub.load(repo_or_dir="facebookresearch/dinov2", model=backbone_name)
    backbone.eval()
    backbone.to(device)
    print("Backbone loaded\n")

    sample_img, _, _, _ = dataset[0]
    sample_img = sample_img.unsqueeze(0).to(device)
    with torch.no_grad():
        output = backbone.forward_features(sample_img)["x_norm_patchtokens"]
    n_embedding = output.shape[2]
    print(f"Embedding dimension: {n_embedding}")

    print(f"Loading segmentation head from {args.model_path}...")
    classifier = SegmentationHeadConvNeXt(
        in_channels=n_embedding,
        out_channels=n_classes,
        tokenW=w // 14,
        tokenH=h // 14
    )
    
    if not os.path.exists(args.model_path):
        print(f"\nERROR: Model file not found: {args.model_path}")
        print("Please check the path and try again.")
        return
    
    classifier.load_state_dict(torch.load(args.model_path, map_location=device))
    classifier = classifier.to(device)
    classifier.eval()
    print("Model loaded successfully\n")

    print("Running inference on {} images...".format(len(dataset)))

    iou_scores = []
    pixel_accuracies = []
    all_class_iou = []
    vis_count = 0

    with torch.no_grad():
        pbar = tqdm(dataloader, desc="Processing", unit="batch")
        
        for batch_idx, (imgs, labels, data_ids, original_sizes) in enumerate(pbar):
            imgs = imgs.to(device)
            labels = labels.to(device)

            with amp.autocast(device_type='cuda'):
                output = backbone.forward_features(imgs)["x_norm_patchtokens"]
                logits = classifier(output)
                outputs = F.interpolate(logits, size=(h, w), mode="bilinear", align_corners=False)

            predicted_masks = torch.argmax(outputs, dim=1)

            if has_gt:
                labels_squeezed = labels.squeeze(dim=1).long()
                iou, class_iou = compute_iou_per_class(outputs, labels_squeezed, num_classes=n_classes)
                pixel_acc = compute_pixel_accuracy(outputs, labels_squeezed)
                
                iou_scores.append(iou)
                pixel_accuracies.append(pixel_acc)
                all_class_iou.append(class_iou)
                
                pbar.set_postfix({'IoU': f'{iou:.3f}', 'Acc': f'{pixel_acc:.3f}'})
            else:
                pbar.set_postfix({'Status': 'Inferring'})

            for i in range(imgs.shape[0]):
                data_id = data_ids[i]
                base_name = os.path.splitext(data_id)[0]
                original_size = original_sizes[i]

                pred_mask = predicted_masks[i].cpu().numpy().astype(np.uint8)
                pred_mask_resized = cv2.resize(
                    pred_mask, 
                    (original_size[0].item(), original_size[1].item()),
                    interpolation=cv2.INTER_NEAREST
                )

                Image.fromarray(pred_mask_resized).save(
                    os.path.join(masks_dir, f'{base_name}_pred.png')
                )

                pred_color = mask_to_color(pred_mask_resized)
                cv2.imwrite(
                    os.path.join(masks_color_dir, f'{base_name}_pred_color.png'),
                    cv2.cvtColor(pred_color, cv2.COLOR_RGB2BGR)
                )

                img_denorm = denormalize_image(imgs[i])
                img_denorm_resized = cv2.resize(
                    (img_denorm * 255).astype(np.uint8),
                    (original_size[0].item(), original_size[1].item())
                )
                overlay = create_overlay(img_denorm_resized, pred_mask_resized, alpha=0.5)
                cv2.imwrite(
                    os.path.join(overlays_dir, f'{base_name}_overlay.png'),
                    cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
                )

                if vis_count < args.num_vis:
                    gt_mask = labels[i].squeeze().long() if has_gt else None
                    save_prediction_visualization(
                        imgs[i], 
                        predicted_masks[i], 
                        os.path.join(visualizations_dir, f'{base_name}_visualization.png'),
                        data_id,
                        gt_mask=gt_mask,
                        original_size=original_size
                    )
                    vis_count += 1

    print("\nCreating class legend...")
    create_legend(os.path.join(args.output_dir, 'class_legend.png'))

    if has_gt and iou_scores:
        mean_iou = np.nanmean(iou_scores)
        mean_pixel_acc = np.mean(pixel_accuracies)
        avg_class_iou = np.nanmean(all_class_iou, axis=0)

        results = {
            'mean_iou': mean_iou,
            'mean_pixel_acc': mean_pixel_acc,
            'class_iou': avg_class_iou
        }

        print("\nEvaluation Results")
        print(f"Mean IoU:          {mean_iou:.4f}")
        print(f"Pixel Accuracy:    {mean_pixel_acc:.4f}")
        print("\nPer-Class IoU:")
        for name, iou in zip(class_names, avg_class_iou):
            if not np.isnan(iou):
                print(f"  {name:<20}: {iou:.4f}")
            else:
                print(f"  {name:<20}: N/A")

        save_metrics_summary(results, args.output_dir, has_gt=True)

    print("\nInference complete!")
    print(f"\nProcessed {len(dataset)} images successfully")
    print(f"\nOutputs saved to: {args.output_dir}/")
    print(f"  - masks/              : Raw prediction masks")
    print(f"  - masks_color/        : Colored prediction masks")
    print(f"  - overlays/           : Image + mask overlays")
    print(f"  - visualizations/     : Detailed comparisons ({args.num_vis} samples)")
    print(f"  - class_legend.png    : Color legend")
    
    if has_gt:
        print(f"  - evaluation_metrics.txt : Quantitative results")
        print(f"  - per_class_iou.png      : Per-class IoU chart")
    
    print()


if __name__ == "__main__":
    main()