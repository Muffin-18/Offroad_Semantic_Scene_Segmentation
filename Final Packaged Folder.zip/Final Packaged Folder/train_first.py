import math
import os
import random
import time

import cv2
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torchvision.transforms as transforms
from PIL import Image, ImageFilter
from torch.cuda.amp import GradScaler, autocast
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm


class RandomColorJitter:
    def __init__(self, brightness=0.3, contrast=0.3, saturation=0.3, hue=0.1):
        self.jitter = transforms.ColorJitter(
            brightness=brightness,
            contrast=contrast,
            saturation=saturation,
            hue=hue,
        )

    def __call__(self, img):
        if random.random() > 0.5:
            img = self.jitter(img)
        return img


class RandomGammaCorrection:
    def __init__(self, gamma_range=(0.7, 1.5)):
        self.gamma_range = gamma_range

    def __call__(self, img):
        if random.random() > 0.5:
            gamma = random.uniform(*self.gamma_range)
            arr = np.array(img).astype(np.float32) / 255.0
            arr = np.power(arr, gamma)
            img = Image.fromarray((arr * 255).astype(np.uint8))
        return img


class RandomGaussianBlur:
    def __init__(self, sigma_range=(0.1, 2.0)):
        self.sigma_range = sigma_range

    def __call__(self, img):
        if random.random() > 0.7:
            sigma = random.uniform(*self.sigma_range)
            img = img.filter(ImageFilter.GaussianBlur(radius=sigma))
        return img


class RandomShadow:
    def __init__(self, shadow_intensity_range=(0.3, 0.7)):
        self.shadow_intensity_range = shadow_intensity_range

    def __call__(self, img):
        if random.random() > 0.6:
            arr = np.array(img).astype(np.float32)
            h, w = arr.shape[:2]
            intensity = random.uniform(*self.shadow_intensity_range)
            direction = random.choice(["top", "bottom", "left", "right"])

            if direction in ("top", "bottom"):
                gradient = np.linspace(1, intensity, h)[:, None]
                if direction == "bottom":
                    gradient = gradient[::-1]
            else:
                gradient = np.linspace(1, intensity, w)[None, :]
                if direction == "right":
                    gradient = gradient[:, ::-1]

            arr *= gradient[:, :, None]
            img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
        return img


class CoarseDropout:
    def __init__(self, max_holes=8, max_h=40, max_w=40, fill=0, p=0.5):
        self.max_holes = max_holes
        self.max_h = max_h
        self.max_w = max_w
        self.fill = fill
        self.p = p

    def __call__(self, img):
        if random.random() > self.p:
            return img

        arr = np.array(img)
        h, w = arr.shape[:2]
        n_holes = random.randint(1, self.max_holes)

        for _ in range(n_holes):
            rh = random.randint(1, self.max_h)
            rw = random.randint(1, self.max_w)
            y = random.randint(0, max(0, h - rh))
            x = random.randint(0, max(0, w - rw))
            arr[y : y + rh, x : x + rw] = self.fill

        return Image.fromarray(arr)


def save_image(img, filename):
    img = np.array(img)
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    img = np.moveaxis(img, 0, -1)
    img = (img * std + mean) * 255
    cv2.imwrite(filename, img[:, :, ::-1])


value_map = {
    0: 0,
    100: 1,
    200: 2,
    300: 3,
    500: 4,
    550: 5,
    700: 6,
    800: 7,
    7100: 8,
    10000: 9,
}

n_classes = len(value_map)

class_names = [
    "Background", "Trees", "Lush Bushes", "Dry Grass", "Dry Bushes",
    "Ground Clutter", "Logs", "Rocks", "Landscape", "Sky",
]


def convert_mask(mask):
    arr = np.array(mask)
    new_arr = np.zeros_like(arr, dtype=np.uint8)
    for raw_value, new_value in value_map.items():
        new_arr[arr == raw_value] = new_value
    return Image.fromarray(new_arr)


class MaskDataset(Dataset):
    def __init__(self, data_dir, transform=None, mask_transform=None, augment=False):
        self.image_dir = os.path.join(data_dir, "Color_Images")
        self.masks_dir = os.path.join(data_dir, "Segmentation")
        self.transform = transform
        self.mask_transform = mask_transform
        self.augment = augment
        self.data_ids = os.listdir(self.image_dir)

        self._color_jitter = RandomColorJitter()
        self._gamma = RandomGammaCorrection()
        self._blur = RandomGaussianBlur()
        self._shadow = RandomShadow()
        self._cutout = CoarseDropout(max_holes=8, max_h=40, max_w=40, fill=0, p=0.5)

    def __len__(self):
        return len(self.data_ids)

    def __getitem__(self, idx):
        data_id = self.data_ids[idx]
        image = Image.open(os.path.join(self.image_dir, data_id)).convert("RGB")
        mask = Image.open(os.path.join(self.masks_dir, data_id))
        mask = convert_mask(mask)

        if self.augment:
            if random.random() > 0.5:
                image = transforms.functional.hflip(image)
                mask = transforms.functional.hflip(mask)

            if random.random() > 0.5:
                angle = random.uniform(-10, 10)
                image = transforms.functional.rotate(image, angle)
                mask = transforms.functional.rotate(mask, angle)

            if random.random() > 0.5:
                scale = random.uniform(0.8, 1.2)
                w, h = image.size
                new_w = int(w * scale)
                new_h = int(h * scale)
                image = transforms.functional.resize(
                    image, (new_h, new_w), interpolation=transforms.InterpolationMode.BILINEAR
                )
                mask = transforms.functional.resize(
                    mask, (new_h, new_w), interpolation=transforms.InterpolationMode.NEAREST
                )

            image = self._color_jitter(image)
            image = self._gamma(image)
            image = self._blur(image)
            image = self._shadow(image)
            image = self._cutout(image)

        if self.transform:
            image = self.transform(image)
        if self.mask_transform:
            mask = self.mask_transform(mask)

        return image, mask


class _ASPPConv(nn.Sequential):
    def __init__(self, in_ch, out_ch, dilation):
        super().__init__(
            nn.Conv2d(in_ch, out_ch, 3, padding=dilation, dilation=dilation, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.GELU(),
        )


class _ASPPPooling(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.pool = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_ch, out_ch, 1, bias=True),
            nn.GELU(),
        )

    def forward(self, x):
        size = x.shape[2:]
        out = self.pool(x)
        return F.interpolate(out, size=size, mode="bilinear", align_corners=False)


class ASPP(nn.Module):
    def __init__(self, in_ch, out_ch=256, rates=(6, 12, 18)):
        super().__init__()
        modules = [
            nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1, bias=False),
                nn.BatchNorm2d(out_ch),
                nn.GELU(),
            )
        ]
        for rate in rates:
            modules.append(_ASPPConv(in_ch, out_ch, rate))
        modules.append(_ASPPPooling(in_ch, out_ch))

        self.branches = nn.ModuleList(modules)
        self.project = nn.Sequential(
            nn.Conv2d(out_ch * len(self.branches), out_ch, 1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.GELU(),
            nn.Dropout(0.1),
        )

    def forward(self, x):
        out = torch.cat([branch(x) for branch in self.branches], dim=1)
        return self.project(out)


class PositionalEncoding2D(nn.Module):
    def __init__(self, n_freqs=8):
        super().__init__()
        self.n_freqs = n_freqs
        self.out_channels = n_freqs * 2 * 2

    def forward(self, x):
        B, C, H, W = x.shape
        device = x.device
        y_coords = torch.linspace(0, 1, H, device=device).view(1, 1, H, 1).expand(B, 1, H, W)
        x_coords = torch.linspace(0, 1, W, device=device).view(1, 1, 1, W).expand(B, 1, H, W)
        pe_list = []
        for freq in range(self.n_freqs):
            factor = 2 ** freq
            pe_list.append(torch.sin(2 * math.pi * factor * y_coords))
            pe_list.append(torch.cos(2 * math.pi * factor * y_coords))
            pe_list.append(torch.sin(2 * math.pi * factor * x_coords))
            pe_list.append(torch.cos(2 * math.pi * factor * x_coords))
        pe = torch.cat(pe_list, dim=1)
        return pe


class ConvNeXtBlock(nn.Module):
    def __init__(self, in_channels, out_channels=None, expansion=4):
        super().__init__()
        out_channels = out_channels or in_channels
        hidden_dim = in_channels * expansion

        self.dwconv = nn.Conv2d(in_channels, in_channels, kernel_size=7, padding=3, groups=in_channels)
        self.norm = nn.LayerNorm(in_channels)
        self.pwconv1 = nn.Linear(in_channels, hidden_dim)
        self.act = nn.GELU()
        self.pwconv2 = nn.Linear(hidden_dim, out_channels)
        
        self.shortcut = nn.Identity() if in_channels == out_channels else nn.Conv2d(in_channels, out_channels, 1)

    def forward(self, x):
        input = x
        x = self.dwconv(x)
        x = x.permute(0, 2, 3, 1)
        x = self.norm(x)
        x = self.pwconv1(x)
        x = self.act(x)
        x = self.pwconv2(x)
        x = x.permute(0, 3, 1, 2)
        x = x + self.shortcut(input)
        return x


class SegmentationHeadConvNeXt(nn.Module):
    def __init__(self, in_channels, out_channels, tokenW, tokenH):
        super().__init__()
        self.tokenW = tokenW
        self.tokenH = tokenH
        
        self.pos_enc = PositionalEncoding2D(n_freqs=8)
        pe_channels = self.pos_enc.out_channels
        
        self.aspp = ASPP(in_channels, out_ch=256, rates=(6, 12, 18))
        
        total_in = 256 + pe_channels
        
        self.conv1 = nn.Sequential(
            nn.Conv2d(total_in, 512, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(512),
            nn.GELU(),
        )
        
        self.convnext1 = ConvNeXtBlock(512, 512, expansion=4)
        self.convnext2 = ConvNeXtBlock(512, 512, expansion=4)
        
        self.conv2 = nn.Sequential(
            nn.Conv2d(512, 256, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(256),
            nn.GELU(),
        )
        
        self.classifier = nn.Conv2d(256, out_channels, kernel_size=1)

    def forward(self, x):
        B, N, C = x.shape
        x = x.transpose(1, 2).reshape(B, C, self.tokenH, self.tokenW)
        
        pos_enc = self.pos_enc(x)
        aspp_out = self.aspp(x)
        x = torch.cat([aspp_out, pos_enc], dim=1)
        
        x = self.conv1(x)
        x = self.convnext1(x)
        x = self.convnext2(x)
        x = self.conv2(x)
        x = self.classifier(x)
        
        return x


class FocalLoss(nn.Module):
    def __init__(self, alpha=None, gamma=2.0):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, logits, labels):
        ce_loss = F.cross_entropy(logits, labels, weight=self.alpha, reduction="none")
        pt = torch.exp(-ce_loss)
        focal_loss = (1 - pt) ** self.gamma * ce_loss
        return focal_loss.mean()


class DiceLoss(nn.Module):
    def __init__(self, num_classes, smooth=1.0):
        super().__init__()
        self.num_classes = num_classes
        self.smooth = smooth

    def forward(self, logits, labels):
        probs = F.softmax(logits, dim=1)
        labels_one_hot = F.one_hot(labels, self.num_classes).permute(0, 3, 1, 2).float()
        
        dice_per_class = []
        for c in range(self.num_classes):
            pred_c = probs[:, c, :, :]
            true_c = labels_one_hot[:, c, :, :]
            
            intersection = (pred_c * true_c).sum()
            union = pred_c.sum() + true_c.sum()
            
            dice = (2.0 * intersection + self.smooth) / (union + self.smooth)
            dice_per_class.append(dice)
        
        dice_per_class = torch.stack(dice_per_class)
        return 1.0 - dice_per_class.mean()


class CombinedLoss(nn.Module):
    def __init__(self, class_weights=None, dice_weight=0.5, focal_weight=0.5, gamma=2.0):
        super().__init__()
        self.dice_weight = dice_weight
        self.focal_weight = focal_weight
        self.focal_loss = FocalLoss(alpha=class_weights, gamma=gamma)
        self.dice_loss = DiceLoss(num_classes=len(class_weights) if class_weights is not None else 10)

    def forward(self, logits, labels):
        focal = self.focal_loss(logits, labels)
        dice = self.dice_loss(logits, labels)
        return self.focal_weight * focal + self.dice_weight * dice


def compute_class_weights(dataset, num_classes, device):
    class_counts = torch.zeros(num_classes, dtype=torch.float32)
    
    print("Computing class frequencies for weighting...")
    for _, mask in tqdm(dataset, desc="Class weights"):
        mask_long = (mask.squeeze() * 255).long()
        for c in range(num_classes):
            class_counts[c] += (mask_long == c).sum().item()
    
    total_pixels = class_counts.sum()
    class_freqs = class_counts / total_pixels
    class_weights = 1.0 / (class_freqs + 1e-6)
    class_weights = class_weights / class_weights.sum() * num_classes
    
    class_weights = class_weights.to(device)
    
    print("Class weights:")
    for i, (name, weight) in enumerate(zip(class_names, class_weights)):
        print(f"  {name:<20}: {weight:.4f}")
    
    return class_weights


def compute_iou(preds, labels, num_classes):
    ious = []
    for cls in range(num_classes):
        pred_mask = (preds == cls)
        true_mask = (labels == cls)
        intersection = (pred_mask & true_mask).sum().float()
        union = (pred_mask | true_mask).sum().float()
        if union == 0:
            ious.append(float("nan"))
        else:
            ious.append((intersection / union).item())
    return np.array(ious)


def validate(backbone, model, loader, loss_fct, device, num_classes):
    model.eval()
    total_loss = 0.0
    total_correct = 0
    total_pixels = 0
    all_ious = []

    with torch.no_grad():
        for imgs, labels in loader:
            imgs = imgs.to(device)
            labels = labels.to(device).squeeze(1).long()

            with autocast():
                tokens = backbone.forward_features(imgs)["x_norm_patchtokens"]
                logits = model(tokens)
                outputs = F.interpolate(logits, size=imgs.shape[2:], mode="bilinear", align_corners=False)
                loss = loss_fct(outputs, labels)

            total_loss += loss.item()
            preds = torch.argmax(outputs, dim=1)
            total_correct += (preds == labels).sum().item()
            total_pixels += labels.numel()

            ious = compute_iou(preds, labels, num_classes)
            all_ious.append(ious)

    val_loss = total_loss / len(loader)
    val_acc = total_correct / total_pixels
    all_ious = np.array(all_ious)
    per_class_iou = np.nanmean(all_ious, axis=0)
    val_miou = np.nanmean(per_class_iou)

    return val_loss, val_acc, val_miou, per_class_iou


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = os.path.join(script_dir, "training_outputs")
    os.makedirs(output_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    n_epochs = 50
    batch_size = 16
    lr = 3e-4
    focal_gamma = 2.0
    patience = 10

    w, h = 672, 378
    print(f"Training resolution: {h}x{w}")

    transform = transforms.Compose([
        transforms.Resize((h, w)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])

    mask_transform = transforms.Compose([
        transforms.Resize((h, w), interpolation=transforms.InterpolationMode.NEAREST),
        transforms.ToTensor(),
    ])

    data_root = os.path.join(os.path.dirname(script_dir), "Offroad_Segmentation_Training_Dataset")
    trainset = MaskDataset(os.path.join(data_root, "train"), transform, mask_transform, augment=True)
    valset = MaskDataset(os.path.join(data_root, "val"), transform, mask_transform, augment=False)

    train_loader = DataLoader(trainset, batch_size=batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(valset, batch_size=batch_size, num_workers=0)

    backbone = torch.hub.load("facebookresearch/dinov2", "dinov2_vitb14_reg")
    backbone.eval().to(device)
    for p in backbone.parameters():
        p.requires_grad = False

    imgs, _ = next(iter(train_loader))
    with torch.no_grad():
        tokens = backbone.forward_features(imgs.to(device))["x_norm_patchtokens"]
    embed_dim = tokens.shape[2]
    print(f"Embedding dim: {embed_dim}")

    class_weights = compute_class_weights(trainset, n_classes, device)

    model = SegmentationHeadConvNeXt(embed_dim, n_classes, w // 14, h // 14).to(device)
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Trainable decoder parameters: {total_params:,}")

    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=n_epochs)

    loss_fct = CombinedLoss(
        class_weights=class_weights,
        dice_weight=0.5,
        focal_weight=0.5,
        gamma=focal_gamma,
    )

    scaler = GradScaler()

    best_miou = 0.0
    no_improve = 0
    history = {
        "train_loss": [], "val_loss": [], "val_acc": [], "val_miou": [],
        "lr": [], "per_class_iou": [],
    }

    print(f"\nStarting training for {n_epochs} epochs (patience={patience})\n")

    for epoch in range(n_epochs):
        t0 = time.perf_counter()
        model.train()
        train_loss = 0.0

        pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{n_epochs} [train]")
        for imgs, labels in pbar:
            imgs = imgs.to(device)
            labels = labels.to(device).squeeze(1).long()

            with autocast():
                with torch.no_grad():
                    tokens = backbone.forward_features(imgs)["x_norm_patchtokens"]

                logits = model(tokens)
                outputs = F.interpolate(logits, size=imgs.shape[2:], mode="bilinear", align_corners=False)
                loss = loss_fct(outputs, labels)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad()

            train_loss += loss.item()
            pbar.set_postfix(loss=f"{loss.item():.4f}")

        scheduler.step()
        avg_train_loss = train_loss / len(train_loader)

        val_loss, val_acc, val_miou, per_class_iou = validate(
            backbone, model, val_loader, loss_fct, device, n_classes
        )

        elapsed = time.perf_counter() - t0
        history["train_loss"].append(avg_train_loss)
        history["val_loss"].append(val_loss)
        history["val_acc"].append(val_acc)
        history["val_miou"].append(val_miou)
        history["lr"].append(scheduler.get_last_lr()[0])
        history["per_class_iou"].append(per_class_iou.copy())

        print(
            f"Epoch {epoch+1:>2d}/{n_epochs}  "
            f"train_loss={avg_train_loss:.4f}  "
            f"val_loss={val_loss:.4f}  "
            f"val_acc={val_acc:.4f}  "
            f"val_mIoU={val_miou:.4f}  "
            f"lr={scheduler.get_last_lr()[0]:.2e}  "
            f"time={elapsed:.1f}s"
        )
        iou_strs = "  Per-class IoU: " + " | ".join(
            f"{class_names[c]}={per_class_iou[c]:.3f}" if not np.isnan(per_class_iou[c])
            else f"{class_names[c]}=N/A"
            for c in range(n_classes)
        )
        print(iou_strs)

        if val_miou > best_miou:
            best_miou = val_miou
            no_improve = 0
            save_path = os.path.join(script_dir, "segmentation_head_best.pth")
            torch.save(model.state_dict(), save_path)
            print(f"  New best mIoU={best_miou:.4f} - saved to {save_path}")
        else:
            no_improve += 1
            print(f"  No improvement for {no_improve}/{patience} epochs")

        if no_improve >= patience:
            print(f"\nEarly stopping triggered at epoch {epoch+1}")
            break

    final_path = os.path.join(script_dir, "segmentation_head_final.pth")
    torch.save(model.state_dict(), final_path)
    print(f"\nFinal model saved to {final_path}")
    print(f"Best validation mIoU: {best_miou:.4f}")

    n_epochs_ran = len(history["train_loss"])
    epochs_x = list(range(1, n_epochs_ran + 1))

    fig, axes = plt.subplots(2, 3, figsize=(22, 12))

    axes[0, 0].plot(epochs_x, history["train_loss"], "o-", label="Train Loss")
    axes[0, 0].plot(epochs_x, history["val_loss"], "s-", label="Val Loss")
    axes[0, 0].set_title("Loss (Focal + Macro-Dice)", fontweight="bold")
    axes[0, 0].set_xlabel("Epoch")
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3)

    axes[0, 1].plot(epochs_x, history["val_acc"], "o-", color="green", label="Val Pixel Acc")
    axes[0, 1].set_title("Pixel Accuracy", fontweight="bold")
    axes[0, 1].set_xlabel("Epoch")
    axes[0, 1].set_ylim(0, 1)
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3)

    axes[0, 2].plot(epochs_x, history["val_miou"], "o-", color="purple", label="Val mIoU")
    axes[0, 2].set_title("Mean IoU", fontweight="bold")
    axes[0, 2].set_xlabel("Epoch")
    axes[0, 2].set_ylim(0, 1)
    axes[0, 2].legend()
    axes[0, 2].grid(True, alpha=0.3)

    iou_matrix = np.array(history["per_class_iou"])
    for c in range(n_classes):
        vals = iou_matrix[:, c]
        valid_mask = ~np.isnan(vals)
        if valid_mask.any():
            axes[1, 0].plot(
                np.array(epochs_x)[valid_mask], vals[valid_mask],
                "o-", markersize=3, label=class_names[c],
            )
    axes[1, 0].set_title("Per-Class IoU", fontweight="bold")
    axes[1, 0].set_xlabel("Epoch")
    axes[1, 0].set_ylim(0, 1)
    axes[1, 0].legend(fontsize=7, ncol=2, loc="lower right")
    axes[1, 0].grid(True, alpha=0.3)

    iou_display = np.nan_to_num(iou_matrix.T, nan=0.0)
    im = axes[1, 1].imshow(iou_display, aspect="auto", cmap="RdYlGn", vmin=0, vmax=1)
    axes[1, 1].set_yticks(range(n_classes))
    axes[1, 1].set_yticklabels(class_names, fontsize=8)
    axes[1, 1].set_xticks(range(n_epochs_ran))
    axes[1, 1].set_xticklabels(epochs_x, fontsize=7)
    axes[1, 1].set_xlabel("Epoch")
    axes[1, 1].set_title("IoU Heatmap (per class × epoch)", fontweight="bold")
    fig.colorbar(im, ax=axes[1, 1], shrink=0.8)

    axes[1, 2].plot(epochs_x, history["lr"], "o-", color="orange", label="LR")
    axes[1, 2].set_title("Learning Rate Schedule", fontweight="bold")
    axes[1, 2].set_xlabel("Epoch")
    axes[1, 2].set_yscale("log")
    axes[1, 2].legend()
    axes[1, 2].grid(True, alpha=0.3)

    plt.tight_layout()
    plot_path = os.path.join(output_dir, "training_curves.png")
    plt.savefig(plot_path, dpi=150, bbox_inches="tight")
    print(f"Training curves saved to {plot_path}")
    plt.close()

    print("\nTraining complete.")


if __name__ == "__main__":
    main()